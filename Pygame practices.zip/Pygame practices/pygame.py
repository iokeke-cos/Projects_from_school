pygame.init() 
screen = pygame.display.set_mode((500, 400)) 
clock = pygame.time.Clock() 
 
x, y = 100, 100 
radius = 20 
dx, dy = 3, 3 
running = True 
while running: 
    screen.fill((0, 0, 0)) 
    pygame.draw.circle(screen, (0, 255, 0), (x, y), radius) 
    x += dx 
    y += dy 
    if x - radius < 0 or x + radius > 500: 
        dx *= -1 
    if y - radius < 0 or y + radius > 400:
         dy *= -1 
    for event in pygame.event.get(): 
        if event.type == pygame.QUIT: 
            running = False 
    pygame.display.flip() 
    clock.tick(60) 
pygame.quit() 