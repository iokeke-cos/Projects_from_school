def draw_sphere(): 
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT) 
    glLoadIdentity() 
    glTranslatef(0, 0, -5) 
glutWireSphere(1, 20, 20) 
glutSwapBuffers() 
def main_sphere(): 
glutInit(sys.argv) 
glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH) 
glutInitWindowSize(500, 500) 
glutCreateWindow("Wireframe Sphere") 
glEnable(GL_DEPTH_TEST) 
glutDisplayFunc(draw_sphere) 
glutIdleFunc(draw_sphere) 
glutMainLoop() 
# Uncomment the line below to run the sphere 
 main_sphere()