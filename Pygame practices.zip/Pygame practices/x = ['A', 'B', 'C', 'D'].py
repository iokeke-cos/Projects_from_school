x = ['A', 'B', 'C', 'D'] 
y = [3, 7, 5, 12] 
plt.figure() 
plt.bar(x, y) 
plt.title("Bar Chart Example") 
plt.xlabel("Categories") 
plt.ylabel("Values") 
plt.show()