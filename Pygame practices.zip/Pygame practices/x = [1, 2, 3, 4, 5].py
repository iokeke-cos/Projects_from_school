x = [1, 2, 3, 4, 5] 
y = [2, 4, 1, 8, 7] 
plt.figure() 
plt.scatter(x, y) 
plt.title("Scatter Plot Example") 
plt.xlabel("X-axis") 
plt.ylabel("Y-axis") 
plt.show() 