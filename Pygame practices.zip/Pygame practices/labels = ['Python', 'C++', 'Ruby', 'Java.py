labels = ['Python', 'C++', 'Ruby', 'Java'] 
sizes = [215, 130, 245, 210] 
plt.figure() 
plt.pie(sizes, labels=labels, autopct='%1.1f%%') 
plt.title("Pie Chart Example") 
plt.show() 