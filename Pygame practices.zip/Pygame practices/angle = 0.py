angle = 0 
def draw_cube(): 
    global angle 
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT) 
    glLoadIdentity() 
    glTranslatef(0, 0, -5) 
    glRotatef(angle, 1, 1, 0) 
    glutWireCube(2) 
    glutSwapBuffers() 
    angle += 1 
 
def main_cube(): 
    glutInit(sys.argv) 
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH) 
    glutInitWindowSize(500, 500) 
    glutCreateWindow("Rotating Cube") 
    glEnable(GL_DEPTH_TEST) 
    glutDisplayFunc(draw_cube) 
    glutIdleFunc(draw_cube) 
    glutMainLoop() 
 
# Uncomment the line below to run the cube 
main_cube() 