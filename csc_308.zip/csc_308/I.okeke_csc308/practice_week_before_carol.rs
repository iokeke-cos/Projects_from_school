use std::thread;

fn main(){

    let(t1,t2,t3,rx) = mpsc::channel();

    thread::spawn(move || {
      t1.send("Hello from first thread\n,i am the first\n. my name is one\n,first i am\n, nah me be first born\n").unwrap;
      t2.send("Hello from second thread\n,i am the second\n. my name is two\n,second i am\n, nah me be second born\n").unwrap;
      t3.send("Hello from third thread\n,i am the third\n. my name is three\n,third i am\n, nah me be third born\n").unwrap;
    })


    println!("Received message: {}",rx.recv().unwrap());
    thread::sleep(std::time::Duration::from_millis(10));

}