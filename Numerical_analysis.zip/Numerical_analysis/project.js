console.log("Program started");

function f(x) {
    return Math.pow(x, 3) - 7 * x;
}

function df(x) {
    return 3 * Math.pow(x, 2) - 7;
}

let x0 = 1.5;
let N = 20;
let alpha = Math.sqrt(7);

let x = x0;

console.log("n\t x_n\t\t f(x_n)\t\t |x_n - sqrt(7)|");
console.log("--------------------------------------------------");

for (let n = 1; n <= N; n++) {
    x = x - f(x) / df(x);
    let error = Math.abs(x - alpha);

    console.log(
        n + "\t " +
        x.toFixed(10) + "\t " +
        f(x).toExponential(3) + "\t " +
        error.toExponential(3)
    );
}

console.log("\nEstimated error at n = 20:", Math.abs(x - alpha));
