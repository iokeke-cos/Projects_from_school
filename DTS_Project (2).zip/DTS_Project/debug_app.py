import psycopg2
from psycopg2 import extras
import hashlib
import sys
from datetime import datetime

# --- POSTGRESQL CONNECTION ROUTINE ---
def get_db_connection():
    """Establishes connection to your teammate's PostgreSQL instance safely."""
    return psycopg2.connect(
        host="localhost",
        database="sibas_db",  # Target database name from your schema specs
        user="postgres",       # Default PostgreSQL username
        password="your_postgres_password"  # UPDATE THIS CREDENTIAL @ Juzo
    )

# --- SECURITY UTILITIES ---
def hash_password(password: str) -> str:
    """Generates a secure SHA-256 string from plain text input."""
    return hashlib.sha256(password.encode('utf-8')).hexdigest()

def authenticate_user(username, password):
    """Verifies access credentials using safe parameterized SQL tokens."""
    conn = get_db_connection()
    # DictCursor allows matching rows by column string name exactly like SQLite rows
    cursor = conn.cursor(cursor_factory=extras.DictCursor)
    hpw = hash_password(password)
    
    query = """
        SELECT u.user_id, u.username, r.role_name, u.is_active 
        FROM users u 
        JOIN roles r ON u.role_id = r.role_id 
        WHERE u.username = %s AND u.password_hash = %s
    """
    cursor.execute(query, (username, hpw))
    user = cursor.fetchone()
    
    cursor.close()
    conn.close()
    return user

# --- ADMIN PANEL ---
def admin_dashboard():
    while True:
        print("\n--- ADMINISTRATOR DASHBOARD ---")
        print("1. Create User Account")
        print("2. System Directory")
        print("3. Log Out")
        choice = input("Select an option: ")

        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=extras.DictCursor)

        if choice == "1":
            new_u = input("Username: ")
            new_p = input("Password: ")
            role_type = input("Role (1 for Lecturer, 2 for Student): ")
            f_name = input("First Name: ")
            l_name = input("Last Name: ")
            ident = input("ID Value (Staff/Matric Number): ")

            if not (new_u and new_p and f_name and l_name and ident):
                print("Error: All fields are mandatory.")
                cursor.close()
                conn.close()
                continue

            role_name = "Lecturer" if role_type == "1" else "Student"
            try:
                cursor.execute("SELECT role_id FROM roles WHERE role_name = %s;", (role_name,))
                rid = cursor.fetchone()['role_id']
                hashed_val = hash_password(new_p)
                
                # PostgreSQL uses RETURNING to safely capture auto-increment IDs
                cursor.execute(
                    "INSERT INTO users (username, password_hash, role_id) VALUES (%s, %s, %s) RETURNING user_id;", 
                    (new_u, hashed_val, rid)
                )
                new_uid = cursor.fetchone()['user_id']
                
                target_tbl = "lecturers" if role_name == "Lecturer" else "students"
                col_lbl = "staff_number" if role_name == "Lecturer" else "matric_number"
                
                cursor.execute(
                    f"INSERT INTO {target_tbl} (user_id, first_name, last_name, {col_lbl}) VALUES (%s, %s, %s, %s);", 
                    (new_uid, f_name, l_name, ident)
                )
                conn.commit()
                print(f"Success: System profile created for {new_u}!")
            except Exception as err:
                conn.rollback()
                print(f"Execution Error: {err}")
                
        elif choice == "2":
            cursor.execute(
                "SELECT u.user_id, u.username, r.role_name, u.is_active FROM users u JOIN roles r ON u.role_id = r.role_id WHERE u.role_id != 1;"
            )
            users = cursor.fetchall()
            for row in users:
                status = "Active" if row['is_active'] else "Inactive"
                print(f"ID: {row['user_id']} | User: {row['username']} ({row['role_name']}) | Status: {status}")
            input("\nPress Enter to return...")
            
        elif choice == "3":
            cursor.close()
            conn.close()
            break
            
        cursor.close()
        conn.close()

# --- LECTURER PANEL ---
def lecturer_dashboard(user_id):
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=extras.DictCursor)
    cursor.execute("SELECT lecturer_id FROM lecturers WHERE user_id = %s;", (user_id,))
    lec = cursor.fetchone()
    cursor.close()
    conn.close()
    
    if not lec:
        print("Profile mismatch issue encountered.")
        return
    lec_id = lec['lecturer_id']

    while True:
        print("\n--- INSTRUCTOR TERMINAL ---")
        print("1. Launch New Attendance Session")
        print("2. View Course Attendance Logs")
        print("3. Log Out")
        choice = input("Select an option: ")

        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=extras.DictCursor)

        if choice == "1":
            cursor.execute("SELECT course_id, course_code FROM courses WHERE lecturer_id = %s;", (lec_id,))
            my_courses = cursor.fetchall()
            if not my_courses:
                print("You are not currently assigned to any courses.")
                cursor.close()
                conn.close()
                continue
            
            for c in my_courses:
                print(f"ID: {c['course_id']} | Code: {c['course_code']}")
            target_c = input("Select Course ID to open attendance window: ")
            
            now_date = datetime.now().strftime("%Y-%m-%d")
            now_time = datetime.now().strftime("%H:%M:%S")
            
            cursor.execute(
                "INSERT INTO attendance_sessions (course_id, session_date, start_time, is_active) VALUES (%s, %s, %s, TRUE);", 
                (target_c, now_date, now_time)
            )
            conn.commit()
            print(f"Attendance session is now OPEN for course ID {target_c}.")

        elif choice == "2":
            query = """
                SELECT s.session_id, c.course_code, s.session_date, 
                       (SELECT count(*) FROM attendance_records WHERE session_id = s.session_id AND status = 'Present') as attendees
                FROM attendance_sessions s
                JOIN courses c ON s.course_id = c.course_id
                WHERE c.lecturer_id = %s
            """
            cursor.execute(query, (lec_id,))
            logs = cursor.fetchall()
            if not logs:
                print("No attendance logs found for your courses.")
                cursor.close()
                conn.close()
                continue
            for log in logs:
                print(f"Session ID: {log['session_id']} | Course: {log['course_code']} | Date: {log['session_date']} | Present Count: {log['attendees']}")
            input("\nPress Enter to return...")
            
        elif choice == "3":
            cursor.close()
            conn.close()
            break
            
        cursor.close()
        conn.close()

# --- STUDENT PANEL ---
def student_dashboard(user_id):
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=extras.DictCursor)
    cursor.execute("SELECT student_id FROM students WHERE user_id = %s;", (user_id,))
    stu = cursor.fetchone()
    cursor.close()
    conn.close()
    
    if not stu:
        print("Profile mismatch issue encountered.")
        return
    stu_id = stu['student_id']

    while True:
        print("\n--- 🎓 STUDENT PORTAL ---")
        print("1. Register Attendance (Check-in)")
        print("2. View My Attendance Performance")
        print("3. Log Out")
        choice = input("Select an option: ")

        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=extras.DictCursor)

        if choice == "1":
            query = """
                SELECT s.session_id, c.course_code 
                FROM attendance_sessions s
                JOIN courses c ON s.course_id = c.course_id
                JOIN enrollments e ON c.course_id = e.course_id
                WHERE e.student_id = %s AND s.is_active = TRUE
            """
            cursor.execute(query, (stu_id,))
            active_windows = cursor.fetchall()
            
            if not active_windows:
                print("ℹ️ There are no active attendance sessions open for your enrolled courses right now.")
                cursor.close()
                conn.close()
                continue
                
            for w in active_windows:
                print(f"Session Window Code: {w['session_id']} | Course: {w['course_code']}")
            target_sid = input("Select Session Code to mark presence: ")
            
            try:
                now_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                cursor.execute(
                    "INSERT INTO attendance_records (session_id, student_id, status, marked_at) VALUES (%s, %s, 'Present', %s);", 
                    (target_sid, stu_id, now_ts)
                )
                conn.commit()
                print("Checked-in successfully! Your attendance has been logged.")
            except Exception as e:
                conn.rollback()
                print("Check-in Error: You may already be checked in for this session.")

        elif choice == "2":
            query = """
                SELECT c.course_code, r.status, r.marked_at
                FROM attendance_records r
                JOIN attendance_sessions s ON r.session_id = s.session_id
                JOIN courses c ON s.course_id = c.course_id
                WHERE r.student_id = %s
            """
            cursor.execute(query, (stu_id,))
            my_records = cursor.fetchall()
            if not my_records:
                            print("No attendance entries found for your account.")
            cursor.close()
            conn.close()
            continue

        for rec in my_records:
            print(f"Course: {rec['course_code']} | Status: {rec['status']} | Signed-At: {rec['marked_at']}")
        input("\nPress Enter to return...")

        elif choice == "3":
            cursor.close()
            conn.close()
            break
        

        cursor.close()
        conn.close()


# --- CORE ENGINE ---
def main_app():
    while True:
        print("\n====================================")
        print("    SIBAS PORTAL (POSTGRESQL MODE)")
        print("====================================")
        print("1. Log In")
        print("2. Exit System")
        choice = input("Select an option: ")

        if choice == "1":
            u = input("Username: ")
            p = input("Password: ")
            user_rec = authenticate_user(u, p)

            if user_rec:
                if not user_rec['is_active']:
                    print("Account is deactivated.")
                    continue
                print(f"Logged in as {user_rec['username']} ({user_rec['role_name']})")

                if user_rec['role_name'] == "Administrator":
                    admin_dashboard()
                elif user_rec['role_name'] == "Lecturer":
                    lecturer_dashboard(user_rec['user_id'])
                elif user_rec['role_name'] == "Student":
                    student_dashboard(user_rec['user_id'])
            else:
                print("Invalid username or password.")
        elif choice == "2":
            sys.exit()


if __name__ == "__main__":
    main_app()

