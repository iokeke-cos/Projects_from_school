import streamlit as st
import sqlite3
import bcrypt

# --- IN-MEMORY DEMO DATABASE SETUP ---
@st.cache_resource
def init_demo_db():
    """Creates a temporary in-memory database to simulate your PostgreSQL schema."""
    conn = sqlite3.connect(":memory:", check_same_thread=False)
    conn.row_factory = sqlite3.Row  # Dict-like cursor behavior like psycopg2
    cursor = conn.cursor()
    
    # 1. Create Schema Tables
    cursor.execute("CREATE TABLE roles (role_id INTEGER PRIMARY KEY AUTOINCREMENT, role_name TEXT UNIQUE);")
    cursor.execute("""
        CREATE TABLE users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT, 
            username TEXT UNIQUE, 
            password_hash TEXT, 
            role_id INTEGER, 
            is_active INTEGER DEFAULT 1,
            FOREIGN KEY(role_id) REFERENCES roles(role_id)
        );
    """)
    cursor.execute("CREATE TABLE lecturers (lecturer_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, first_name TEXT, last_name TEXT, staff_number TEXT UNIQUE);")
    cursor.execute("CREATE TABLE students (student_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, first_name TEXT, last_name TEXT, matric_number TEXT UNIQUE);")
    cursor.execute("CREATE TABLE courses (course_id INTEGER PRIMARY KEY AUTOINCREMENT, course_code TEXT UNIQUE, course_title TEXT, lecturer_id INTEGER);")
    cursor.execute("CREATE TABLE attendance_sessions (session_id INTEGER PRIMARY KEY AUTOINCREMENT, course_id INTEGER, session_date TEXT, start_time TEXT, is_active INTEGER DEFAULT 1);")
    cursor.execute("CREATE TABLE attendance_records (session_id INTEGER, student_id INTEGER, status TEXT, PRIMARY KEY (session_id, student_id));")

    # 2. Seed Mock Roles
    cursor.executemany("INSERT INTO roles (role_name) VALUES (?);", [("Administrator",), ("Lecturer",), ("Student",)])
    
    # 3. Helper to Seed Initial Mock Accounts safely with bcrypt
    def create_mock_user(username, password, role_id, first, last, identifier, table):
        hpw = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        cursor.execute("INSERT INTO users (username, password_hash, role_id) VALUES (?, ?, ?);", (username, hpw, role_id))
        uid = cursor.lastrowid
        if table == "lecturers":
            cursor.execute("INSERT INTO lecturers (user_id, first_name, last_name, staff_number) VALUES (?, ?, ?, ?);", (uid, first, last, identifier))
        elif table == "students":
            cursor.execute("INSERT INTO students (user_id, first_name, last_name, matric_number) VALUES (?, ?, ?, ?);", (uid, first, last, identifier))

    create_mock_user("admin", "adminpassword", 1, "Sys", "Admin", "ADM001", None)
    create_mock_user("prof_smith", "lecturerpassword", 2, "Charles", "Smith", "Lec123", "lecturers")
    create_mock_user("john_doe", "studentpassword", 3, "John", "Doe", "STU456", "students")
    
    # 4. Seed Mock Course
    cursor.execute("INSERT INTO courses (course_code, course_title, lecturer_id) VALUES (?, ?, ?);", ("DTS304", "Data Management I", 1))
    
    conn.commit()
    return conn

# Connect to our isolated demo sandbox
db_conn = init_demo_db()

# --- BACKEND UTILITY FUNCTIONS ---
def check_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def authenticate_user(username, password):
    cursor = db_conn.cursor()
    query = """
        SELECT u.user_id, u.username, u.password_hash, r.role_name, u.is_active 
        FROM users u 
        JOIN roles r ON u.role_id = r.role_id 
        WHERE u.username = ?
    """
    cursor.execute(query, (username,))
    user = cursor.fetchone()
    if user and user['is_active'] and check_password(password, user['password_hash']):
        return user
    return None

# --- STREAMLIT STATE CONTROL ---
if 'auth' not in st.session_state:
    st.session_state.auth = {"status": False, "uid": None, "user": None, "role": None}

# --- VIEW INTERFACES ---
def login_page():
    st.title("🔒 SIBAS Gateway (Debug Mode)")
    with st.form("auth_form"):
        u_input = st.text_input("Username")
        p_input = st.text_input("Password", type="password")
        if st.form_submit_button("Authenticate"):
            user_rec = authenticate_user(u_input, p_input)
            if user_rec:
                st.session_state.auth = {"status": True, "uid": user_rec['user_id'], "user": user_rec['username'], "role": user_rec['role_name']}
                st.success("Access Granted.")
                st.rerun()
            else:
                st.error("Authentication failed or account disabled.")

def admin_view():
    st.header("🛡️ Admin Workspace")
    opt = st.selectbox("Action Menu", ["Create Identity Record", "System Directory"])
    cursor = db_conn.cursor()

    if opt == "Create Identity Record":
        with st.form("creation_form"):
            new_u = st.text_input("Account Username")
            new_p = st.text_input("Account Password", type="password")
            role_type = st.selectbox("Assigned Scope", ["Lecturer", "Student"])
            f_name = st.text_input("First Name")
            l_name = st.text_input("Last Name")
            ident = st.text_input("ID Value (Staff / Matric)")
            
            if st.form_submit_button("Commit to Database"):
                if not (new_u and new_p and f_name and l_name and ident):
                    st.error("Missing mandatory system configurations.")
                else:
                    try:
                        cursor.execute("SELECT role_id FROM roles WHERE role_name = ?;", (role_type,))
                        rid = cursor.fetchone()['role_id']
                        hashed_val = hash_password(new_p)
                        
                        cursor.execute("INSERT INTO users (username, password_hash, role_id) VALUES (?, ?, ?);", (new_u, hashed_val, rid))
                        new_uid = cursor.lastrowid
                        
                        target_tbl = "lecturers" if role_type == "Lecturer" else "students"
                        col_lbl = "staff_number" if role_type == "Lecturer" else "matric_number"
                        
                        cursor.execute(f"INSERT INTO {target_tbl} (user_id, first_name, last_name, {col_lbl}) VALUES (?, ?, ?, ?);", 
                                       (new_uid, f_name, l_name, ident))
                        db_conn.commit()
                        st.success(f"System profile generated for {new_u}.")
                    except Exception as err:
                        db_conn.rollback()
                        st.error(f"Execution Error: {err}")

    elif opt == "System Directory":
        cursor.execute("SELECT u.user_id, u.username, r.role_name, u.is_active FROM users u JOIN roles r ON u.role_id = r.role_id WHERE u.role_id != 1;")
        for row in cursor.fetchall():
            c1, c2, c3 = st.columns([3, 2, 2])
            c1.write(f"🏷️ **{row['username']}** ({row['role_name']})")
            
            lbl = "Deactivate" if row['is_active'] else "Activate"
            if c2.button(lbl, key=f"tgl_{row['user_id']}"):
                cursor.execute("UPDATE users SET is_active = ? WHERE user_id = ?;", (0 if row['is_active'] else 1, row['user_id']))
                db_conn.commit()
                st.rerun()
                
            if c3.button("Purge Account", key=f"del_{row['user_id']}"):
                cursor.execute("DELETE FROM users WHERE user_id = ?;", (row['user_id'],))
                db_conn.commit()
                st.rerun()

def lecturer_view():
    st.header("👨‍🏫 Instructor Terminal")
    st.info("System fully operational. Authenticated to generate new attendance metrics and course sessions.")
    # Ready for your teammate's data logic integration

def student_view():
    st.header("🎓 Student Terminal")
    st.info("System fully operational. Authenticated to check into logs and verify system registry entries.")
    # Ready for your teammate's verification logic integration

# --- CENTRAL APP RUNNER ---
if not st.session_state.auth["status"]:
    login_page()
else:
    st.sidebar.title("SIBAS Console")
    st.sidebar.caption(f"Role Scope: {st.session_state.auth['role']}")
    st.sidebar.write(f"Identity: **{st.session_state.auth['user']}**")
    
    if st.sidebar.button("Terminate Session"):
        st.session_state.auth = {"status": False, "uid": None, "user": None, "role": None}
        st.rerun()

    # RBAC Screen Routing
    if st.session_state.auth["role"] == "Administrator":
        admin_view()
    elif st.session_state.auth["role"] == "Lecturer":
        lecturer_view()
    elif st.session_state.auth["role"] == "Student":
        student_view()
